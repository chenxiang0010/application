
/****   request.js   ****/
// 导入axios
import axios from 'axios'
// 使用element-ui MessageBox做消息提醒
import { MessageBox } from 'element-ui';
import router from '@/router/index'
//import qs from 'qs'
/**请求时显示加载动画 函数声明 S*/
import { Loading } from 'element-ui'
let _ = require('lodash');
let loading

function startLoading() {
  loading = Loading.service({
    lock: true,
    text: '加载中……',
    // background: 'rgba(0, 0, 0, 0.5)'//黑色背景
  })
}


function showFullScreenLoading() {
  startLoading()
}

function tryHideFullScreenLoading() {
  _.debounce(tryCloseLoading, 300)()//防止函数抖动，当有多个loading的时候避免间隔闪烁
}

const tryCloseLoading = () => {
  loading.close()
}
/**请求时显示加载动画 E*/

//1. 创建新的axios实例，
const service = axios.create({
  // 公共接口
  baseURL: process.env.BASE_API,
  // 超时时间 单位是ms，这里设置了3s的超时时间
  timeout: 3 * 1000,
  showLoading: true,//是否开启loading动画
});


// 2.请求拦截器
service.interceptors.request.use(config => {
  if (config.showLoading) {//开启loading
    showFullScreenLoading()
  }
  // console.log(config);
  let token=localStorage.getItem('token')
  //发请求前做的一些处理，数据转化，配置请求头，设置token,设置loading等，根据需求去添加
  config.headers = {
    'Content-Type': 'application/json',//配置请求头
  }
  if(token){
    config.headers.token=token
  }
  return Promise.resolve(config)
}, error => {
  Promise.reject(error)
})

// 3.响应拦截器
service.interceptors.response.use(response => {
  if (response.config.showLoading) {//关闭loading
    tryHideFullScreenLoading()
  }
  let data = response.data;
  if (data.ErrorCode === -3 || data.Msg === "未登录或登录超时") {
    MessageBox.alert('登录超时!请重新登录', '提示信息', {
      type: 'error',
      dangerouslyUseHTMLString: true,
      callback: function () {
        router.push('/');
      }
    });
  }
  return data
}, error => {
  var errStr = '';
  /***** 接收到异常响应的处理开始 *****/
  if (error && error.response) {

    // 1.公共错误处理
    // 2.根据响应码具体处理
    errStr = error.message;
  } else {

    // 超时处理
    if (JSON.stringify(error).includes('timeout')) {
      errStr = '服务器响应超时，请刷新当前页';

    }
    errStr = '连接服务器失败';

  }
  MessageBox.alert(errStr, '提示信息', {
    type: 'error',
    dangerouslyUseHTMLString: true,
    callback: () => {
      tryCloseLoading()
    }
  })

  /***** 处理结束 *****/
  //如果不需要错误处理，以上的处理过程都可省略
  return Promise.reject(error.response)
})
//4.导入文件
export default service