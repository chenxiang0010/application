/* 
init : 初始化对象
initData :初始化数据
render : 渲染数据
handle : 执行抽奖功能
getPosition : 定位盒子

el : 抽奖板块 
prizeInfo: 奖品信息
prizeImg: 奖品图片
winner : 指定中奖奖品
isAssign : 是否开启指定中奖

*/
let lottery = {
    init: function (options) {
        this.initData(options);
        this.render();
        this.handle();
    },
    initData: function (options) {
        [
            this.el,
            this.prizeInfo,
            this.prizeImg,
            this.winner,
            this.isAssign
        ] = [
            document.querySelector(options.el),
            options.prizeInfo,
            ["1", "2", "3", "4", "5", "6", "7", "8", ],
            options.winner,
            options.isAssign
        ],
            this.boxWidth = 100, //盒子宽高
            this.boxSpacing = 5, //盒子间隙
            this.boxSum = 3, //盒子列数
            this.childLength = this.boxSum * this.boxSum - 1, // 盒子总数 3 x 3 - 1
            this.positionArr = this.getPosition() // 盒子定位
    },
    getPosition: function () {
        let arr = [];
        //定位盒子的临界值
        let [criticalValue1, criticalValue2, criticalValue3, criticalValue4] = [
            0,
            this.boxSum,
            this.boxSum * 2 - 1,
            this.boxSum * 3 - 2,
        ]
        //确定跑马灯盒子的位置
        for (let i = 0; i < this.childLength; i++) {
            if (i >= criticalValue1 && i < criticalValue2) {
                arr.push({
                    top: 0 + "px",
                    left: i * (this.boxWidth + this.boxSpacing) + "px"
                })
            } else if (i >= criticalValue2 && i < criticalValue3) {
                arr.push({
                    right: 0 + "px",
                    top: (this.boxWidth + this.boxSpacing) * (i - criticalValue2 + 1) + "px"
                })
            } else if (i >= criticalValue3 && i < criticalValue4) {
                arr.push({
                    bottom: 0 + "px",
                    right: (this.boxWidth + this.boxSpacing) * (i - criticalValue3 + 1) + "px"
                })
            } else {
                arr.push({
                    left: 0 + "px",
                    bottom: (this.boxWidth + this.boxSpacing) * (i - criticalValue4 + 1) + "px"
                })
            }
        }
        return arr;
    },
    render: function () {
        //生成元素
        for (let i = 0; i < this.childLength; i++) {
            let oDiv = document.createElement("div");
            oDiv.setAttribute("class", "lottery-item");
            //更改单个盒子的大小
            oDiv.style.width = this.boxWidth + "px";
            oDiv.style.height = this.boxWidth + "px";
            let oImg = document.createElement("img");
            oImg.setAttribute("src", "./images/" + (i + 1) + ".png");
            let oP = document.createElement("p");
            oP.innerText = this.prizeInfo[i];
            oDiv.appendChild(oImg);
            oDiv.appendChild(oP);
            [
                oDiv.style.top,
                oDiv.style.left,
                oDiv.style.right,
                oDiv.style.bottom,
            ] = [
                this.positionArr[i].top,
                this.positionArr[i].left,
                this.positionArr[i].right,
                this.positionArr[i].bottom
            ]
            this.el.appendChild(oDiv);
        }
        //更改总盒子大小
        let boxWidthHeight = (this.boxWidth + this.boxSpacing) * this.boxSum - this.boxSpacing + "px";
        this.el.style.width = boxWidthHeight;
        this.el.style.height = boxWidthHeight;

        //生成中间抽奖按钮
        let oBtnDiv = document.createElement("div");
        oBtnDiv.setAttribute("class", "lottery-btn");
        oBtnDiv.style.width = this.boxWidth + "px";
        oBtnDiv.style.height = this.boxWidth + "px";
        this.el.appendChild(oBtnDiv);
    },
    handle: function () {
        let self = this;
        let oBtn = this.el.querySelector(".lottery-btn"); //获取点击抽奖按钮
        let oItem = self.el.querySelectorAll(".lottery-item img"); //获取所有的图片
        let i = -1; //转动的索引位置 
        let count = 0; //转圈初始值
        let totalCount = 9; //转动的总圈数
        let speed = 500; //转圈速度，越大越慢
        let minSpeed = 500; //转圈速度
        let index = this.winner; //指定转到哪个奖品
        let isClick = true;
        let timer;

        function roll() {
            //速度衰减
            speed -= 50;
            if (speed <= 10) {
                speed = 10;
            }
            //每次调用都去掉全部active类名
            for (let j = 0; j < oItem.length; j++) {
                oItem[j].classList.remove('lottery-on');
            }
            i++;
            //计算转圈次数
            if (i >= oItem.length) {
                i = 0;
                count++;
            }
            oItem[i].classList.add("lottery-on");
            //满足转圈数和指定位置就停止
            if (count >= totalCount && (i + 1) === index) {
                clearTimeout(timer);
                isClick = true;
                speed = minSpeed;
            } else {
                timer = setTimeout(roll, speed); //不满足条件时调用定时器
                //最后一圈减速
                if (count >= totalCount - 1 || speed <= 50) {
                    speed += 100;
                }
            }

        }
        oBtn.onclick = function () {
            if (isClick) {
                count = 0;
                //随机产生中奖位置
                if (!self.isAssign) {
                    index = Math.floor(Math.random() * oItem.length + 1);
                }
                roll()
                isClick = false;
                // console.log(self.prizeInfo[index]);
            }
        }
    },
}